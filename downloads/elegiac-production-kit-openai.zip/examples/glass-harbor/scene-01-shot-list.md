# Scene 01 — The Answer

| Shot | Type | Est. | What happens | Hero | Clip | Status |
|---|---|---:|---|---|---|---|
| S01-010 | Wide | 6s | Elian crosses the wet breakwater toward the signal house | — | — | Planned |
| S01-020 | Medium | 5s | The receiver repeats a broken ship name | — | — | Planned |
| S01-030 | Close-up | 4s | Elian removes the left glove and touches the vibrating glass | — | — | Planned |
| S01-040 | Long lens | 6s | Three lighthouses answer in sequence across the bay | — | — | Planned |
