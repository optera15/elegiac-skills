# Glass Harbor — Style

- **Palette:** sodium amber, deep green-black water, oxidized teal, winter grey
- **Lighting:** practical harbor lamps and cold predawn sky
- **Texture:** wet 35mm grain, halation around lamps, restrained contrast
- **Composition:** patient wides, compressed observation, strong foreground obstructions
- **Never:** glossy fantasy spectacle, clean cyan/orange grading, legible accidental signage
