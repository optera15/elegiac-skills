# Glass Harbor — Production Brief

**Logline:** During the final ferry of winter, a harbor pilot discovers that every lighthouse is answering a distress signal from a ship erased from the town's records.

- **Format:** 90-second atmospheric short
- **Delivery:** 16:9, 2K masters, web/festival teaser
- **Tone:** restrained supernatural mystery
- **Principal:** Elian Voss, adult harbor pilot, practical and sleep-deprived
