# North Breakwater

An exposed concrete arm protecting the old harbor. Rusted rails, a squat glass signal house, black water below, and three distant lighthouses aligned across the bay.

Continuity: rain has stopped, surfaces remain wet, warning beacon rotates every six seconds.
