# Video Prompt — S01-040

Twenty-one-second sequence endpoint, 6-second shot. From behind Elian's shoulder inside the dark signal house, hold a compressed view across rain-streaked glass. The nearest lighthouse blooms once in sodium amber; two more answer from deeper across the bay at measured two-second intervals. Elian remains almost still, breath catching only after the third pulse. Slow focus transfer from the glass reflection to the farthest light. Wet 35mm texture, practical exposure, no camera shake, no music; distant foghorn and receiver static only. End on the third light fading into predawn grey.

## Prompt Log

- **v1** — example initial prompt; not generated.
