# Elian Voss

- **Role:** Lead
- **Locked look:** Adult in their early forties; weathered face, short dark curls threaded with grey, alert brown eyes.
- **Wardrobe:** Navy wool watch cap, orange oilskin over charcoal layers, black deck gloves.
- **Continuity:** Left glove is removed only after shot S01-030.
- **Rights:** Original fictional character; no real-person likeness.
