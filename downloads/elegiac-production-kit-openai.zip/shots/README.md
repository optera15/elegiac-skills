# Shot Lists

Create one `scene-[NN]-[name].md` per scene using the table in `SKILL.md`. Number shots by tens and keep Hero/Clip/Status columns tied to approved assets.
