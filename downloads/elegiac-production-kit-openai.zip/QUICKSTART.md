# Quickstart

1. Create a ChatGPT Project for the film.
2. Paste `chatgpt/PROJECT_INSTRUCTIONS.md` into Project settings.
3. Upload `SKILL.md` plus `chatgpt/PRODUCTION_CONTEXT.md`, `chatgpt/WORKING_STATE.md`, and `chatgpt/PROMPT_TOOLKIT.md`.
4. Type **Open the production office**.
5. Approve story, style, cast, coverage, and spending gates as they arrive.

If this is an exported kit, ChatGPT opens with a Call Sheet. If it is blank, start with a logline, aspect ratio, platform, and target runtime.

When ChatGPT supplies replacement context or state Markdown, replace the corresponding Project source so future chats inherit the latest production state.
