# Assets

- `moodboard/`: user-provided visual direction.
- `curated/`: approved hero stills organized by scene and shot ID.
- `video/`: approved clips organized by scene, shot ID, and take.

Recommended names:

- `scene-[NN]-shot-[SSS]-hero-[index].png`
- `scene-[NN]-shot-[SSS]-take-[TT].mp4`

ChatGPT can inspect attached media but does not silently move or rename local files. Treat its file-management output as an explicit proposed manifest.
