# Story Department

Keep the production brief and scene breakdown here. `story-notes.md` is local creative intent; when a live Production changes, reconcile before replacing it.
