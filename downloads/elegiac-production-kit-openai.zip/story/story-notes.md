# Story Notes

## Logline

[One sentence]

## Delivery specifications

- Aspect ratio:
- Resolution:
- Target runtime:
- Platform/audience:

## Characters

[Name, role, want, obstacle, change]

## Scene breakdown

| Scene | Location/time | Beat | Essential dialogue | Visual purpose |
|---|---|---|---|---|
| 1 | | | | |
