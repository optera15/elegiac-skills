# Production Context

> Blank starter. Elegiac replaces this file with a consolidated live-production render during export.

## Project

- **Production:** Untitled
- **productionId:** Not bound
- **Logline:**
- **Audience / platform:**
- **Aspect ratio / resolution:**
- **Target runtime:**

## Story and scenes

[Premise, numbered scenes, beats, and essential dialogue]

## Cast canon

[Character, role, cast ID when connected, locked look, wardrobe rule, arc, rights/provenance]

## Style canon

[Palette, lighting, texture, lens/composition language, style-system ID, explicit exclusions]

## Locations and hero props

[Recurring environment/prop canon and reference links]

## Shot coverage

[Per-scene shot tables]

## Asset links

[Approved references, heroes, and clips]
