# Working State

> Blank starter. Replace this source in full after durable status, continuity, or handoff changes.

## Call Sheet

- **Studio link:** Portable
- **Locked:** Nothing yet
- **Shooting today:** Project intake
- **Blocked:** Story and delivery specifications
- **Credits:** No spend

## Production tracker

| Department | Item | Status | Next action |
|---|---|---|---|
| Story | Project intake | Not started | Supply logline and delivery specs |

## Continuity state

| Scene | Character/location/prop | State | Notes |
|---|---|---|---|
| — | — | — | — |

## Generation log

| Date | Operation/model | Prompt version | Batch | Keepers | Credits | Notes |
|---|---|---|---:|---:|---:|---|
| — | — | — | — | — | — | — |

## Handoff

- **Last completed:** None
- **Decisions:** None
- **Open questions:** Story, aspect ratio, runtime, platform
- **Next action:** Run intake
