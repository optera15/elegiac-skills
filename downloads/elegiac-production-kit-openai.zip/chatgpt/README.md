# ChatGPT Upload Pack

Paste `PROJECT_INSTRUCTIONS.md` into Project settings. Upload these four sources:

1. `../SKILL.md`
2. `PRODUCTION_CONTEXT.md`
3. `WORKING_STATE.md`
4. `PROMPT_TOOLKIT.md`

After a session, replace `PRODUCTION_CONTEXT.md` or `WORKING_STATE.md` only with a complete replacement produced by ChatGPT or a fresh Elegiac export. Keep older copies outside the Project if you need an audit trail.
