# Prompt Toolkit

Use references and stable Elegiac IDs when tools support them. In Portable mode, attach approved images and include only the minimum visual identity needed in text.

## Image prompt

```text
[SHOT ID] [shot size and camera position].
Subject/action: [one observable moment].
Environment: [story-relevant set details].
Lighting/time: [specific motivated light].
Composition/lens: [framing, depth, movement implication].
Continuity: [wardrobe, props, physical state for this scene].
Exclude: [only concrete failure modes not governed by a style system].
```

## Image edit

```text
Keep [identity, composition, camera, light, and approved elements] unchanged.
Change only [single edit].
Preserve [continuity-critical details].
```

## Video prompt

```text
[SHOT ID], [duration].
Opening state: [what the approved hero establishes].
Performance/action: [ordered physical beats].
Camera: [movement, framing change, focus behavior].
Environment motion: [wind, practical light, particles, crowd].
Dialogue/SFX: [exact line and delivery, or ambience].
End state: [pose/composition needed for the next cut].
No baked-in music unless explicitly requested.
```

## Casting direction

```text
Create distinct casting interpretations for [role], an adult [story function].
Preserve: [non-negotiable story facts].
Vary: age range, facial structure, energy, and lived-in detail.
Neutral wardrobe and consistent portrait setup; no celebrity likeness.
```

## Location reference set

```text
The same empty [location] in four coherent views: establishing wide, reverse,
key playing area, and texture/detail. Preserve architecture, palette, light,
weather, period, and hero-prop placement. No people or accidental text.
```

## Prompt version log

Record every prompt that produces a batch:

```text
v[number] — [date] — [what changed] — [batch size / keepers / credits / lesson]
```

## Safety and rights

- Describe adult characters unambiguously when age could be unclear.
- Use cinematic, anatomical, and wardrobe language; avoid gratuitous body emphasis.
- Do not imitate a living artist or public figure when rights are not confirmed.
- Never use an attached face or voice beyond the rights recorded in the production.
- If a provider rejects a prompt, preserve the creative intent while rewriting only the risky wording.
