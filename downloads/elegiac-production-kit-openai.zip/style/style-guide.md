# Style Guide

- **Style system ID:**
- **Tone keywords:**
- **Palette:**
- **Lighting:**
- **Texture / medium:**
- **Lens and composition:**
- **Period / production design:**
- **Aspect ratio / resolution:**

## Binding exclusions

- Never:
- Avoid:

## Approved references

[Links or filenames]
