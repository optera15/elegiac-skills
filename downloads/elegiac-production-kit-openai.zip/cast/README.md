# Cast Department

Store one Markdown sheet per cast member and downloaded references under `cast/refs/<name>/`. Durable canon belongs in the Elegiac character bible when Connected.
