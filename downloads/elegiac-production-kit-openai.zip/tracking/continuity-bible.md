# Continuity Bible

Durable cast and style canon belongs in Elegiac when Connected. Track per-scene deltas here.

## Characters

| Scene | Character | Outfit | Carrying | Physical/emotional state | Notes |
|---|---|---|---|---|---|
| 1 | | | | | |

## Locations

| Scene | Location | Light/weather | Set state | Changes after scene |
|---|---|---|---|---|
| 1 | | | | |

## Hero props

| Scene | Prop | Position/holder | Condition | Notes |
|---|---|---|---|---|
| 1 | | | | |
