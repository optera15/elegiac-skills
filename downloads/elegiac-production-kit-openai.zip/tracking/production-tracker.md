# Production Tracker

## Project

- **Production:** Untitled
- **productionId:** Not bound
- **Studio link:** Portable
- **Aspect ratio / resolution:**
- **Target runtime / platform:**
- **Last reconciled:** Never

## Departments

| Department | Item | Status | Next action |
|---|---|---|---|
| Story | Intake | Not started | Supply logline and delivery specs |
| Style | Style lock | Not started | Review references |
| Cast | Principals | Not started | Define roles |
| Locations | Recurring sets | Not started | Break down scenes |
| Shots | Coverage | Not started | Lock scenes first |
| Stills | Heroes | Not started | Lock coverage first |
| Video | Clips | Not started | Approve heroes first |
| Delivery | Manifest | Not started | Curate finals |

## Credits

- **Known spend:** 0
- **Pending approvals:** None

## Notes and decisions

[Open questions, decisions, and risks]
