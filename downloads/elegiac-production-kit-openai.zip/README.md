# Elegiac Production Kit for ChatGPT Projects

This kit turns a ChatGPT Project into a durable AI-film production office while keeping live assets, cast identity, style systems, jobs, approvals, and credit spend in Elegiac.

It supports two entry states:

1. **Exported production:** the kit is prefilled from Elegiac with cast sheets, style, board/shot digests, asset links, trackers, and live IDs.
2. **Blank start:** the context files begin empty and ChatGPT guides story intake before anything is generated.

## Set up the ChatGPT Project

1. Create a new Project in ChatGPT.
2. Paste `chatgpt/PROJECT_INSTRUCTIONS.md` into Project settings.
3. Add these four Project sources:
   - `SKILL.md`
   - `chatgpt/PRODUCTION_CONTEXT.md`
   - `chatgpt/WORKING_STATE.md`
   - `chatgpt/PROMPT_TOOLKIT.md`
4. Start a chat with “Open the production office.”

The four-file pack fits the smallest documented ChatGPT Project file allowance. The complete folder remains your portable archive and contains the individual cast, style, shot, prompt, asset, and tracking documents. See the [official ChatGPT Projects guide](https://help.openai.com/en/articles/10169521-using-projects-in-chatgpt) for current Project behavior and limits.

## Working model

- **Connected:** an Elegiac tool is available in the Project chat, so ChatGPT can read live state and run approved actions.
- **Portable:** ChatGPT plans, reviews attachments, and writes prompts without pretending to call Elegiac.

ChatGPT cannot silently rewrite the unzipped kit or replace Project sources. After durable changes it supplies complete replacement Markdown for the affected source; replace the old source or save the response back to the Project.

## Folder map

| Path | Purpose |
|---|---|
| `SKILL.md` | Production-office workflow and guardrails |
| `chatgpt/` | Four-file Project setup and consolidated context |
| `elegiac/manifest.json` | Binding to the live Production and export target |
| `story/`, `cast/`, `locations/`, `style/`, `shots/` | Human-readable production departments |
| `prompts/` | Versioned portable prompts |
| `assets/` | Reference, curated, and video media |
| `tracking/` | Tracker, continuity, generation log, and handoff state |
| `references/` | Detailed guidance loaded only when needed |
| `examples/` | Original worked production slice |
