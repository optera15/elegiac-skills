# Locations and Hero Props

Store one sheet per recurring environment or story-critical prop. Record its dramatic purpose, locked design, reference URLs, and scene-by-scene state changes.
