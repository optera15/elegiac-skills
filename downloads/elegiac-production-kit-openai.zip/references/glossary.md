# Glossary

- **Board:** Elegiac workspace containing creative artifacts and generated media.
- **Call Sheet:** Compact session-opening status: locked work, next task, blockers, credits.
- **Cast ID:** Stable Elegiac identity used to apply a locked character to generations.
- **Connected mode:** ChatGPT has an authorized Elegiac tool available in the current chat.
- **Continuity:** Visual and story state that must persist across related shots.
- **Hero:** Approved still chosen to represent or seed a shot.
- **Hero prop:** Story-critical object that needs stable design and state.
- **Hit rate:** Keepers divided by generated outputs for a batch.
- **Portable mode:** Planning and prompts without a live Elegiac tool.
- **Project source:** A file or saved response attached to a ChatGPT Project for durable context.
- **Shot ID:** Stable identifier such as `S02-030`.
- **Style system:** Elegiac's reusable visual rules, references, prompt, and exclusions.
- **Take:** One generated video candidate for a shot.
