# Sync Protocol — Elegiac and ChatGPT Project

## Ownership

| Fact | Source of truth |
|---|---|
| Assets, URLs, approval labels, jobs, credit spend | Elegiac |
| Cast/style canon and stable IDs | Elegiac when Connected |
| Unexecuted creative intent and per-scene state | Project sources |
| Tracker status | Rebuild from live facts, then overlay local intent |

## Reconcile

1. Read `elegiac/manifest.json` or the manifest section in `PRODUCTION_CONTEXT.md`.
2. Pull the bound Production, boards, cast, style systems, and recent jobs when tools are available.
3. Report disagreements before changing context.
4. Elegiac wins for live facts; Project sources win for unpushed creative intent.
5. Produce complete replacement context/state documents and identify them clearly.

Never silently overwrite a user-edited Project source. A CLI `elegiac kit sync` refreshes the local folder and creates `*.sync-new.*` sidecars for edited files unless `--force` is explicitly used.

`targetSystem` in the manifest must remain `openai` so refreshes retain this ChatGPT adapter.
