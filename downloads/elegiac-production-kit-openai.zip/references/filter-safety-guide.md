# Filter and Rights Safety

Preserve the story while making prompts precise, non-exploitative, and rights-aware.

## Before generation

- Confirm every depicted person is an adult when age is not obvious.
- Record consent and permitted uses for real-person likenesses and voices.
- Confirm ownership or permission for source images, music, logos, and scripts.
- Treat restricted rights as a hard stop.

## Safer phrasing patterns

| Avoid vague/risky phrasing | Prefer production language |
|---|---|
| “looks exactly like [public figure]” | Describe an original character using approved, non-identifying traits |
| Body-focused wording | Wardrobe construction, silhouette, blocking, expression, and camera framing |
| Ambiguous youth terms | “adult character, age [range]” when relevant |
| Graphic harm detail | Story consequence, reaction, aftermath, sound, shadow, or off-screen implication |
| “copy [living artist]” | Describe medium, palette, texture, composition, era, and lighting |

## When a prompt is rejected

1. Do not repeatedly resubmit unchanged wording.
2. Identify whether the risk is age, likeness, sexuality, violence, illegal activity, or copyrighted imitation.
3. Preserve the dramatic beat and rewrite only the risky expression.
4. Keep approved references attached when they legitimately carry identity/style.
5. Record the rewrite and result in the generation log.
