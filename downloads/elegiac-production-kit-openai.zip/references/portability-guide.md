# Portable Mode

Use Portable mode when no authorized Elegiac tool is available in the current ChatGPT chat.

- Work from uploaded context, working state, and attached reference images.
- Produce tool-agnostic prompts and explicit copy/paste instructions.
- Mark all live IDs, asset status, job status, and credit totals as stale or unknown unless present in the export.
- Never claim to generate, approve, upload, move, rename, or synchronize media.
- Ask the user to attach returned outputs for visual review.
- Update the complete Project state sources after decisions, not after unapproved suggestions.

When Connected mode becomes available, reconcile live Elegiac facts before continuing generation.
