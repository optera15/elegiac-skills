# Optional Cutting Room

Read this only after the user accepts an offer to assemble existing clips.

## Preconditions

- Approved clip order and shot IDs exist.
- The user has authorized local media inspection and output creation.
- Assembly tools are available; otherwise write an edit decision list only.

## Workflow

1. Inventory filename, codec, resolution, frame rate, duration, audio channels, and obvious corruption.
2. Compare total duration with the target runtime and flag missing coverage.
3. Write an edit decision list with shot order, trim notes, transition intent, dialogue/SFX, and gaps.
4. Normalize only when necessary; preserve originals.
5. Assemble a clearly labeled rough cut and separate audio stems where possible.
6. Report technical warnings, creative placeholders, and the exact output filenames.

Never fabricate missing clips, silently alter approved timing, or bake temporary music into finals.
