# Prompt Templates

Use these detailed forms only when the compact `chatgpt/PROMPT_TOOLKIT.md` is insufficient.

## Casting sheet

```text
Create [count] clearly distinct casting interpretations for [character], an adult [role/story function].
Story facts that must not change: [facts].
Vary: age range, facial structure, lived-in detail, posture, and emotional energy.
Presentation: consistent neutral portrait setup, practical wardrobe, no celebrity likeness, no text.
```

## Character reference set

```text
The same approved adult character in a coherent reference set: front portrait,
three-quarter portrait, profile, full body, neutral expression, and two story-relevant expressions.
Preserve face, hair, body proportions, wardrobe construction, palette, age, and identifying details.
Simple consistent background and light; no labels or typography.
```

## Location reference set

```text
The same empty [location] in four coherent views: establishing wide, reverse,
key playing area, and material/detail view. Preserve architecture, geography,
palette, motivated light, weather, period, and hero-prop positions. No people or text.
```

## Shot still

```text
[SHOT ID] — [shot size], [camera height/angle], [lens character].
[Character IDs or attached refs] perform [single observable beat] in [location ID/ref].
Scene continuity: [wardrobe, props, physical state, time, weather].
Composition: [foreground/midground/background, eyeline, negative space].
Lighting: [motivated source and contrast].
Preserve the approved style system/reference; exclude [concrete likely failures].
```

## Video from hero

```text
[SHOT ID], [duration], using the attached approved hero as the opening frame.
Performance beats: [ordered actions].
Camera: [movement and focus behavior].
Environmental motion: [specific secondary motion].
Dialogue/SFX: [exact line, delivery, ambience].
End composition: [needed cut/stitch state].
Preserve identity, wardrobe, props, geography, lighting, and aspect ratio.
No music unless explicitly requested.
```

## Prompt log

```markdown
## Prompt Log
- **v1** (YYYY-MM-DD) — initial; [batch / keepers / credits / lesson]
- **v2** (YYYY-MM-DD) — [change]; [batch / keepers / credits / lesson]
```
