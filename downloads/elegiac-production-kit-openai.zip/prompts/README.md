# Versioned Prompts

Keep one prompt file per cast, location, scene, or shot. End every used prompt with a version log; never erase the version that produced a batch.
