# Changelog

## 1.0 — 2026-07-09

- Added the initial ChatGPT Projects production-office workflow.
- Added a four-source Project upload pack and complete-source replacement protocol.
- Preserved Elegiac manifest, synchronization, continuity, curation, rights, and credit controls.
- Added original reference templates and a worked production example.
