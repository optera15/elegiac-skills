# Quickstart (60 seconds)

1. **Open the folder in Claude Code** (or point a Cowork project at it, instructions: `Follow the workflow in SKILL.md exactly, starting with Step 0.`)
2. **Connect Elegiac** if you can — MCP or `elegiac login`. Not required; it just moves generation from copy-paste to done-for-you.
3. **Type your logline.** "A lighthouse keeper's radio starts receiving transmissions from the future." Claude asks for tech specs (aspect ratio, runtime, platform), then runs the pipeline: style → casting → locations → shot lists → stills → video.
4. **Approve at the gates.** You pick the cast winner, approve the style, direct the coverage. Every credit spend is quoted first.
5. **Come back anytime.** Claude opens each session with a call sheet — what's locked, what's shooting today, what's blocked.

Exported this kit from an Elegiac Production? Skip 3 — Claude reads `elegiac/manifest.json`, pulls live status, and greets you with the call sheet.
