# Elegiac Production Kit

This folder is an AI film production office backed by Elegiac. Follow the workflow in `SKILL.md` exactly, starting with Step 0 (Orient) — it defines your role, the pipeline, and your ongoing duties.

Key rules up front:
- Read `elegiac/manifest.json` first. If it names a `productionId`, this kit is bound to a live Elegiac Production — open with the Call Sheet built from live data, not the welcome message.
- Elegiac is the source of truth for assets and status; these files are the working mirror. Reconcile per `references/sync-protocol.md`.
- Quote before spending. Never generate without a cost the user has seen.
- If no Elegiac MCP or CLI is available, run in Portable mode (plans and portable prompts only) — never drive a web app or another provider yourself.
