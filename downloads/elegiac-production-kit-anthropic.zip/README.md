# Elegiac Production Kit

A film-production kit that pairs a local folder of working documents with a live Elegiac Production. Claude runs the production office; Elegiac runs the studio.

**One template, two ways in:**

1. **Blank start.** Download this folder, open it in Claude Code (or point a Claude Desktop/Cowork project at it), and bring a story. Claude walks the full pipeline — style, casting, locations, shot lists, stills, video — generating through Elegiac when connected, or writing portable prompts when not.
2. **Exported from Elegiac.** Export a Production Kit from any Production inside Elegiac and you get this same folder *pre-filled*: cast sheets rendered from your character bibles, the style guide from your style system, shot lists from your boards, curated heroes already downloaded, tracker and generation log seeded from real history. Open it in Claude and the production office picks up mid-stride — the `elegiac/manifest.json` IDs keep everything bound to the live Production.

## Why this beats a generic AI-film template

Generic templates make *you* the asset librarian: drop images into folders, repeat @-tag descriptions in every prompt, hand-maintain a continuity bible, and hope the model holds a face across a hundred generations. Elegiac already does that work natively:

| Generic template | Here |
|---|---|
| @-tags + repeated reference-grid language | Cast members with real identity continuity (`castId`) |
| style-guide.md of adjectives | Style system with a binding `negativePrompt`, applied by ID |
| Hand-sorted `assets/` folders | Board curation with approve/reject labels; `export_pack` downloads |
| Hand-maintained generation log | Seeded from actual job history, with real credit costs |
| Filter-safe language gymnastics | Reference images carry the look; prompts stay about story and camera |
| Continuity bible from scratch | Character bibles hold the canon; the local grid tracks per-scene state |

The folder still matters: it's the part that travels. Shot lists you can read on a plane, a portable brief you can take to any generator, a handoff a collaborator can open cold.

## Setup

- **Claude Code:** open this folder and type anything — `CLAUDE.md` orients Claude automatically.
- **Claude Desktop / Cowork:** new project → add `SKILL.md` → instructions: `Follow the workflow in SKILL.md exactly, starting with Step 0.` → point the project at this folder.
- **Connect Elegiac** (recommended): add the Elegiac MCP to Claude, or authenticate the `elegiac` CLI. Without it, everything still works in Portable mode — Claude plans and writes prompts; you generate in the Elegiac web app or any tool.

## What's in the folder

| Path | Purpose |
|---|---|
| `SKILL.md` | The production office brain — pipeline + ongoing duties |
| `elegiac/manifest.json` | Binding to the live Production (IDs, export + sync metadata) |
| `story/` `cast/` `locations/` `style/` `shots/` | The working documents, one folder per department |
| `prompts/` | Portable prompts + the compiled portable brief |
| `assets/curated/` `assets/video/` | Downloaded heroes and clips, named by shot ID |
| `tracking/` | Tracker, generation log, continuity bible, session handoff |
| `references/` | Sync protocol and portability guide |
