# Generation Log

> Every batch, either mode. In Connected mode, seed rows from Elegiac job history (tool, model, credits) instead of asking the user — then add the judgment columns (keepers, hit rate, what worked) by looking at the results. This becomes the production's private playbook: reference it when writing new prompts ("close-up batches under the style system hit 40% — same structure here").

| Date | Scene/target | Tool · model | Prompt (file · version) | Batch | Keepers | Hit rate | Credits | Notes |
|------|--------------|--------------|--------------------------|-------|---------|----------|---------|-------|
| | | | | | | | | |
