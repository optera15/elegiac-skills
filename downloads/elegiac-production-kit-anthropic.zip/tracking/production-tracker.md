# Production Tracker

> Working mirror of the live Elegiac Production. In Connected mode, reconcile from Elegiac at session start (Elegiac wins for asset/status facts). On export, Elegiac fills this in.

## Project Info
- **Production**: [name] · `productionId`: [id or —]
- **Studio Link**: [Connected | Portable]  ← set in Step 0
- **Aspect Ratio**: [e.g., 16:9] · **Target Runtime**: [e.g., 90s] · **Platform**: [e.g., YouTube] · **Resolution**: [2K]
- **Style System**: [title] · `styleSystemId`: [id or —]
- **Started**: [date] · **Last Reconciled**: [date]

---

## Cast

| Cast member | `castId` | Casting round | Look locked | Bible | Refs curated | Status |
|-------------|----------|---------------|-------------|-------|--------------|--------|
| | | 🔲 | 🔲 | 🔲 | 0 | 🔲 Not started |

## Locations & Hero Props

| Location / prop | Concept on board | Refs curated | Status |
|-----------------|------------------|--------------|--------|
| | 🔲 | 0 | 🔲 Not started |

## Scenes

Per-shot detail lives in `shots/` — this table stays high-level.

| # | Scene | Shot list | Board | Stills | Heroes | Clips | Status |
|---|-------|-----------|-------|--------|--------|-------|--------|
| 1 | | 🔲 | 🔲 | 0 | 0 | 0 | 🔲 Not started |

---

## Credits
- **Quoted & approved this production**: [running total if known]
- **Pending approvals**: [approvalUrl waiting? what for?]

## Status Key
🔲 Not started · 🔄 In progress · ✅ Complete · ⏸️ On hold · 🔁 Needs redo

## Notes
[Decisions, issues, open questions]
