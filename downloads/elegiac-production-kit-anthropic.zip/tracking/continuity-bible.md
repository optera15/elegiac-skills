# Continuity Bible — Per-Scene State Grid

> Division of labor: the **durable canon** (locked look, wardrobe rules, visual continuity notes) lives in the Elegiac character bible — push changes there with `update_character_bible`. This file tracks what the bible can't: **per-scene state** — who wears what *in scene 4*, which hand carries the radio, whether the coat is soaked yet. Consult before every still and video batch.

---

## Characters

### [Name] (`castId`: [id])
**Locked look:** [one line from the curated reference set — face/hair signature]
**Bible wardrobe rule:** [from `wardrobe` field — the default]

| Scene | Outfit (deltas from default) | Carrying | Physical state | Notes |
|-------|------------------------------|----------|----------------|-------|
| 1 | | | | |
| 2 | | | | |

---

## Locations

### [Name]
**Locked look:** [signature features from the approved reference frames]

| Scene | State / changes | Notes |
|-------|-----------------|-------|
| 1 | [e.g., "door intact, lights on"] | |

---

## Hero Props

### [Name]
**Locked look:** [distinguishing marks]

| Scene | Where it is | Condition | Notes |
|-------|-------------|-----------|-------|
| 1 | | | |
