# Sync Protocol — Elegiac ↔ Kit

The kit is a mirror, not a fork. These rules keep the two sides honest.

## Source-of-truth split

| Fact | Owner |
|---|---|
| Assets, their URLs, approval labels, job status, credit spend | **Elegiac** |
| Cast canon (bible, rights, locked look), style rules | **Elegiac** (character bible / style system) |
| Creative intent not yet executed — shot lists, briefs, scene notes, per-scene continuity state | **Kit files** |
| Tracker status columns | Derived — rebuild from Elegiac, then overlay local intent |

## Session-start reconcile (Connected mode)

1. Read `elegiac/manifest.json` → `productionId`, board/style IDs, `sync.lastReconciledAt`.
2. Pull live state: production overview (`elegiac://production/{id}` or `list_boards` + `list_characters` + `list_style_systems`), recent jobs.
3. Update the tracker's status columns and the generation log from live data.
4. Diff local creative docs against board artifacts. Local edits newer than `lastReconciledAt` → offer to push (see below). Board artifacts newer → offer to re-render the local file.
5. Stamp `sync.lastReconciledAt`, then present the Call Sheet with a one-line note of what was reconciled.

Never silently overwrite a local file that has uncommitted creative edits — show the diff and ask.

## Automated pull-refresh — `elegiac kit sync`

`elegiac kit sync` (run from the kit folder, or `elegiac kit sync <dir>`) automates the pull half of the reconcile:

- Re-renders every Elegiac-owned file (cast sheets, style guide, shot digests, curated manifest, trackers) from live state, keeping the kit's board scope from the manifest (`--all-boards` widens, `--boards` re-scopes).
- Honors the no-silent-overwrite rule mechanically: a file with local edits is left untouched and the fresh render lands beside it as `*.sync-new.*` — review, merge, delete the sidecar. `--force` accepts the live render for everything.
- Downloads media for the packs recorded in `assets.packs`, fetching only files not already on disk (`--media refs,curated,video` widens the packs).
- Refreshes `SKILL.md` and the other template files when the kit template's `skillVersion` has moved on (same edit protection applies).
- Stamps `sync.lastReconciledAt` and refreshes `sync.fileHashes` — the baseline that tells local edits from live drift. Kits materialized before baselines existed treat every drifted file as edited on the first sync (safe, noisy once).

Sync never writes to Elegiac. Pushing local work up stays a deliberate act, below.

## Pushing local work up

- **Shot lists — `elegiac kit push`** (run from the kit folder, or `elegiac kit push <dir>`). Pushes locally authored scene shot lists (`shots/scene-*.md` in the Step 5 table format) up to the production's board as shot-list cards:
  - Candidates are `shots/*.md` files **not** in the `sync.fileHashes` baseline — rendered board digests are pull-owned and never pushed.
  - The Shot / Type / Est. / What-happens columns become the card's shots. **Hero, Clip, and Status columns stay local** — they're asset check-in state, and Elegiac owns asset facts (see the source-of-truth split).
  - First push of a file creates a card (`add_shot_list`; target `--board <id>`, or the kit's sole board); later pushes patch the same card (`update_board_artifact`). Each push is recorded in `sync.pushedArtifacts` (path, boardId, boardItemId, payload hash, timestamp), so unchanged lists — including Hero/Status-only edits — are skipped. `--dry-run` previews.
  - A `permission_required` response means the user must approve board writes in Elegiac once; re-run the same command after.
- Briefs / scene notes → board artifacts (creative direction, brief) — still a manual, deliberate act via the board tools; record pushes in `sync.pushedArtifacts` the same way.
- Look-level continuity changes (wardrobe rule changes, new scars, prop redesigns) → `update_character_bible`.
- New reference images the user dropped locally → `upload_asset`, then attach where they belong.

## Pulling assets down

- Use `export_pack` per board/campaign; save its manifest into `elegiac/manifest.json` under `assets.packs` so the next reconcile knows what's already local.
- Downloaded files keep their `suggestedFilename`, then get renamed to shot-ID convention when curated into `assets/curated/`.

## Portable mode

No reconcile possible. Mark the tracker `Studio Link: Portable`, keep everything local, and note in `tracking/handoff.md` that Elegiac state may have drifted — the first Connected session runs a full reconcile.
