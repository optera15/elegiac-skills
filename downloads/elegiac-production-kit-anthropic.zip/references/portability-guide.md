# Portability Guide — Taking the Production Anywhere

The kit's second job is being an escape hatch: everything needed to continue the film in *any* tool, without Elegiac connected. This guide covers writing the portable prompts that make that true.

## When portable prompts are the right tool

- Portable mode (no Elegiac connection this session)
- The user wants to generate in a specific outside tool (Midjourney, Seedance web, Veo, etc.)
- Compiling the master `prompts/portable-brief.md` at delivery time

In Connected mode, don't write portable prompts for work Elegiac will do — apply cast by `castId` and style by `styleSystemId` instead.

## The golden rule

**Let reference images carry the look; let text carry story and camera.** The kit ships the locked reference images (`cast/refs/`, `locations/refs/`, `assets/curated/`). A portable prompt should attach those and describe only: the moment, the action, the shot type, the camera behavior, the light. Re-describing a face in words is how drift starts.

## Portable prompt anatomy (stills)

```
[GROUNDING] Photorealistic cinematic still from a {genre} film — {film-stock/grade line from style/style-guide.md}.
[REFERENCES] Attach: {character ref frames}, {location ref frames}. The attached references define the character and set exactly.
[MOMENT] {what is happening — one continuous beat}
[CAMERA] {shot type, lens feel, angle — from the shot list row}
[LIGHT] {practical sources, time of day, atmosphere — from the style guide}
[NEVER] {the style system's negative-prompt rules, spelled out} · Do not write text on the image. No subtitles. No captions.
```

## Portable prompt anatomy (video)

Structured shot-action format, portable across Seedance-class models:

```
【Style】 {style summary + dominant camera behavior} 【Duration】 {5 or 10}s
Characters: {Name}: {ONE line, references attached do the rest}
Shot 1 ({beat name}): {shot type}. {physical action; camera movement; environment reaction; inline dialogue/SFX cues}
```

- 2–3 shots per 10-second clip, maximum.
- Cue dialogue/ambience/SFX inline. **Never prompt for music** — score in post.
- Chain consecutive clips by attaching clip N's final frame as clip N+1's opening reference.

## Filter safety

Outside tools can't see Elegiac's continuity context, so stacked trigger language (weapon + violence + crime terms) trips their filters. Principles:

- Fewer adjectives about bodies and violence; more about camera and light. The reference image already shows the blade.
- Swap loaded nouns for neutral ones: *gang → house/clan*, *assassin → (name only)*, *kill → (omit; imply)*, *bloodied → after the encounter*, *weapon → the object's plain name*.
- If a batch keeps tripping, cut the prompt's descriptive middle entirely and let the attached references + shot-list beat carry it.

## Every portable prompt file

Lives in `prompts/`, one file per subject or scene, and ends with a `## Prompt Log` (version, date, change, batch performance). The compiled `prompts/portable-brief.md` orders them: casting → character refs → locations → per-scene stills → per-scene video, each block with a one-line usage instruction.
